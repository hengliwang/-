clear;
clc;

[F X] = GetF(100);
tic;
C = Greedy(F,X);
a = toc;
