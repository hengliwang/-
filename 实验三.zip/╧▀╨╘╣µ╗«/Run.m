clear;
clc;

[F X] = GetF(100);
Cost = ones(100,1);
tic;
C = Linear( F,X,Cost );
a = toc;

[F X] = GetF(500);
Cost = ones(500,1);
tic;
C = Linear( F,X,Cost );
b = toc;

[F X] = GetF(1000);
Cost = ones(1000,1);
tic;
C = Linear( F,X,Cost );
c = toc;

[F X] = GetF(2000);
Cost = ones(2000,1);
tic;
C = Linear( F,X,Cost );
d = toc;

[F X] = GetF(5000);
Cost = ones(5000,1);
tic;
C = Linear( F,X,Cost );
e = toc;

